maintaptour.html yang fix
index.html buat landing page

index2.html buat data page